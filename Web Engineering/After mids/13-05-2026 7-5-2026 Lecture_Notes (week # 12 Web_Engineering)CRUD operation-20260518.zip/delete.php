<?php 

include 'connection.php';
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $query = "delete from `signup` where id = $id";
    $query_run = mysqli_query($conn, $query);
    if ($query_run) {
        header('location:display.php');

    }else
    {
        echo die(mysqli_error($conn)).'not deleted';
    }
}
?>